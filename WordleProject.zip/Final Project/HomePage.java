package project;


import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JFrame;

public class HomePage extends JFrame {

    public HomePage() {
    	
        setTitle("Wordle");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLayout(null);
        
        setContentPane(new HomeGui());
        setVisible(true); 
    
    }

    public static void main(String[] args) {
    	new HomePage();
    	Wordle.fileLoader();
    	class Wordle {
    		public static ArrayList<String> myWord; 	
    		
    		public static void fileLoader() {
    		myWord = new ArrayList<String>();
    			
    		String regex = "^[a-zA-Z]+$";
    		Pattern p = Pattern.compile(regex);


    		try(Scanner fileScanner = new Scanner(Paths.get("src/dictionary.txt"))){
    			while(fileScanner.hasNextLine()) {
    				String line = fileScanner.nextLine();
    				Matcher m = p.matcher(line);
    				if(line.length() == 5 && m.matches()) {
    					myWord.add(line);
    				}
    				
    			}
    			fileScanner.close();
    		}
    		catch(Exception e) {
    			System.out.print("Error: " + e.toString());
    		}
    		}//file loader
    		
    		public static String wordToGuess() {
    		if (myWord.size() > 0) {
    		    Random rand = new Random();
    		    String wordToGuess = myWord.get(rand.nextInt(myWord.size()));
    		    System.out.println("Word to guess: " + wordToGuess);

    		return wordToGuess;
    		}
    		return null;

    		}
    	}//wordle class
    		
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    }//the main 

}//the whole jFrame



































//public class HomePage extends JFrame{
//public HomePage() {
//	setTitle("Wordle");
//    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//    setSize(500, 400);
//    setLayout(null);
//}
//
//JButton play  = new JButton("Play Game");
//add(play);
//
//play.addActionListener(new ActionListener() {
//	public void actionPerformed(ActionEvent e) {
//        // Open the second JFrame
//        SecondFrame frame = new SecondFrame();
//        frame.setVisible(true);
//
//        // Close the current JFrame (optional)
//        dispose(); 
//    }
//});
//}//Jframe
//	
//
//public static void main(String[] args) {
//    new HomePage();
//}
//
//
//
//
//
//class frame extends Jframe{
//public frame() {
//		
//JFrame frame = new WordleGui();
//frame.setTitle("WORDLE");
//frame.setSize(500, 400);
//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//frame.setVisible(true);
//}
//}}

