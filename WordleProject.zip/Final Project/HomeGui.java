package project;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class HomeGui extends JPanel{
private JLabel title; 
private JLabel scores; 
//this is all the components of the home page	
public HomeGui() {
homepageContents();
}
	
	
private void homepageContents() {


setLayout(new BorderLayout());

title = new JLabel("WORDLE");
title.setFont(new Font("Arial", Font.BOLD, 30)); 

scores = new JLabel("Top Scores: ", JLabel.LEFT);
scores.setFont(new Font("Arial", Font.PLAIN, 18)); 

add(title, BorderLayout.NORTH); 
add(scores, BorderLayout.CENTER); 

JButton play = new JButton("Play Game");
add(play, BorderLayout.SOUTH);

play.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
    	
    	new WordleGui().setVisible(true);
        dispose();
    }
});




}//Home contents 	


protected void dispose() {}//dispose thing

}//JPanel 
