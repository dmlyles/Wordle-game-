

package project;




import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class Wordle {
private static ArrayList<String> myWord; 	

//class for my dictionary file
public static void fileLoader() {
myWord = new ArrayList<String>();
	
String regex = "^[a-zA-Z]+$";
Pattern p = Pattern.compile(regex);


try(Scanner fileScanner = new Scanner(Paths.get("src/dictionary.txt"))){
	while(fileScanner.hasNextLine()) {
		String line = fileScanner.nextLine();
		Matcher m = p.matcher(line);
		if(line.length() == 5 && m.matches()) {
			myWord.add(line.toLowerCase());
		}
		
	}
	fileScanner.close();
}
catch(Exception e) {
	System.out.print("Error: " + e.toString());
}
}
public static String wordToGuess() {
if (myWord.size() > 0) {
    Random rand = new Random();
    String wordToGuess = myWord.get(rand.nextInt(myWord.size()));
    System.out.println("Word to guess: " + wordToGuess);

return wordToGuess;
}
return null;

}
}//file loader method 	










	
