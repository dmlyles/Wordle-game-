package project;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class WordleGui extends JFrame{
	



	
	
private JButton Exit; 
private JLabel outcome; 
private JButton button;
private JTextField input;
private JTextField input2;
private JTextField input3;
private JTextField input4;
private JTextField input5;
private JTextField input6;
private JTextField input7;
private JTextField input8;
private JTextField input9;
private JTextField input10;
private JTextField input11;
private JTextField input12;
private JTextField input13;
private JTextField input14;
private JTextField input15;
private JTextField input16;
private JTextField input17;
private JTextField input18;
private JTextField input19;
private JTextField input20;
private JTextField input21;
private JTextField input22;
private JTextField input23;
private JTextField input24;
private JTextField input25;





public WordleGui(){
createComponents();
setTitle("WORDLE Game");
setSize(500, 400);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

}

//all the components of the game 
private void createComponents() {
JPanel panel = new JPanel();




GridLayout gridlayout = new GridLayout(6,5);
panel.setLayout(gridlayout);
//
button = new JButton ("Check Word");
button.addActionListener(new WordCheckListener());

Exit = new JButton("Exit");
Exit.addActionListener(new ExitCheckListener());


input = new JTextField("", 1);
input2 = new JTextField("", 1);
input3 = new JTextField("", 1);
input4 = new JTextField("", 1);
input5 = new JTextField("", 1);
input6 = new JTextField("", 1);
input7 = new JTextField("", 1);
input8 = new JTextField("", 1);
input9 = new JTextField("", 1);
input10 = new JTextField("", 1);
input11 = new JTextField("", 1);
input12 = new JTextField("", 1);
input13 = new JTextField("", 1);
input14 = new JTextField("", 1);
input15 = new JTextField("", 1);
input16 = new JTextField("", 1);
input17 = new JTextField("", 1);
input18 = new JTextField("", 1);
input19 = new JTextField("", 1);
input20 = new JTextField("", 1);
input21 = new JTextField("", 1);
input22 = new JTextField("", 1);
input23 = new JTextField("", 1);
input24 = new JTextField("", 1);
input25 = new JTextField("", 1);
//
panel.add(input);
panel.add(input2);
panel.add(input3);
panel.add(input4);
panel.add(input5);
panel.add(input6);
panel.add(input7);
panel.add(input8);
panel.add(input9);
panel.add(input10);
panel.add(input11);
panel.add(input12);
panel.add(input13);
panel.add(input14);
panel.add(input15);
panel.add(input16);
panel.add(input17);
panel.add(input18);
panel.add(input19);
panel.add(input20);
panel.add(input21);
panel.add(input22);
panel.add(input23);
panel.add(input24);
panel.add(input25);
panel.add(button);
panel.add(Exit);
add(panel);

}

//where u can exit to home page 
class ExitCheckListener implements ActionListener{
public void actionPerformed(ActionEvent event) {
	
	dispose();
	

}
}


//random word pulled from dictionary file 
String word = Wordle.wordToGuess();
//this is what loops through the boxes to figure out if your word is correct 
class WordCheckListener implements ActionListener{
public void actionPerformed(ActionEvent event) {

int score = 0; 
JTextField[] inputBox = {input, input2, input3, input4, input5}; 




		for(int n = 0; n < word.length(); n++) {
		JTextField current = inputBox[n];
		String inputText = current.getText();
		
		 if (inputText.length() > 0) {
	         char letter = inputText.charAt(0);         
	         
		if(letter == word.charAt(n)){
			current.setBackground(Color.green);
			score++;
			
			
		}
			else if(word.indexOf(letter) != -1) {
			current.setBackground(Color.yellow);
			
		}
		else {
			current.setBackground(Color.red);
			
		}
		
		 }//if statement that makes sure more than one letter isnt in box
		}//for loop that just run through the hard coded word
		
JTextField[] inputBox2 = {input6, input7, input8, input9, input10};
for(int n = 0; n < word.length(); n++) {
	JTextField current = inputBox2[n];
	String inputText = current.getText();
	
	 if (inputText.length() > 0) {
         char letter = inputText.charAt(0);         
         
	if(letter == word.charAt(n)){
		current.setBackground(Color.green);
		score++;
		
		
	}
		else if(word.indexOf(letter) != -1) {
		current.setBackground(Color.yellow);
		
	}
	else {
		current.setBackground(Color.red);
		
	}
	
	 }//second row if statement that makes sure more than one letter isnt in box
	}//second row for loop that just run through the hard coded word
//
JTextField[] inputBox3 = {input11, input12, input13, input14, input15};
for(int n = 0; n < word.length(); n++) {
	JTextField current = inputBox3[n];
	String inputText = current.getText();
	
	 if (inputText.length() > 0) {
         char letter = inputText.charAt(0);         
         
	if(letter == word.charAt(n)){
		current.setBackground(Color.green);
		score++;
		
		
	}
		else if(word.indexOf(letter) != -1) {
		current.setBackground(Color.yellow);
		
	}
	else {
		current.setBackground(Color.red);
		
	}
	
	 }//third row if statement that makes sure more than one letter isnt in box
	}//third row for loop that just run through the hard coded word
//
JTextField[] inputBox4 = {input16, input17, input18, input19,input20};
for(int n = 0; n < word.length(); n++) {
	JTextField current = inputBox4[n];
	String inputText = current.getText();
	
	 if (inputText.length() > 0) {
         char letter = inputText.charAt(0);         
         
	if(letter == word.charAt(n)){
		current.setBackground(Color.green);
		score++;
		
	}
		else if(word.indexOf(letter) != -1) {
		current.setBackground(Color.yellow);
		
	}
	else {
		current.setBackground(Color.red);
		
	}
	
	 }//fourth row if statement that makes sure more than one letter isnt in box
	}//fourth row for loop that just run through the hard coded word
//
JTextField[] inputBox5 = {input21, input22, input23, input24,input25};
for(int n = 0; n < word.length(); n++) {
	JTextField current = inputBox5[n];
	String inputText = current.getText();
	
	 if (inputText.length() > 0) {
         char letter = inputText.charAt(0);         
         
	if(letter == word.charAt(n)){
		current.setBackground(Color.green);
		score++;
		String message = "Your total score was " + score;
		outcome = new JLabel(message);
		add(outcome, BorderLayout.NORTH);
	}
		else if(word.indexOf(letter) != -1) {
		current.setBackground(Color.yellow);
		
	}
	else {
		current.setBackground(Color.red);
		
	}
	
	 }//fifth row if statement that makes sure more than one letter isnt in box
	}//fifth row for loop that just run through the hard coded word


}//Action Listener
}}//the whole J frame




